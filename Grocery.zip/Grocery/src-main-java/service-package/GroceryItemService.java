package com.example.grocerystore.service;

import com.example.grocerystore.model.GroceryItem;
import java.util.List;

public interface GroceryItemService {
    GroceryItem addGroceryItem(GroceryItem groceryItem);
    GroceryItem updateGroceryItem(Long id, GroceryItem groceryItem);
    void deleteGroceryItem(Long id);
    List<GroceryItem> getAllGroceryItems();
    GroceryItem getGroceryItemById(Long id);
    List<GroceryItem> searchByName(String name);
    List<GroceryItem> searchByCategory(String category);
}
