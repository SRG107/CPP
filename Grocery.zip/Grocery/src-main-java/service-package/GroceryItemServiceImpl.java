package com.example.grocerystore.service.impl;

import com.example.grocerystore.model.GroceryItem;
import com.example.grocerystore.repository.GroceryItemRepository;
import com.example.grocerystore.service.GroceryItemService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GroceryItemServiceImpl implements GroceryItemService {

    private final GroceryItemRepository groceryItemRepository;

    public GroceryItemServiceImpl(GroceryItemRepository groceryItemRepository) {
        this.groceryItemRepository = groceryItemRepository;
    }

    @Override
    public GroceryItem addGroceryItem(GroceryItem groceryItem) {
        return groceryItemRepository.save(groceryItem);
    }

    @Override
    public GroceryItem updateGroceryItem(Long id, GroceryItem groceryItem) {
        if (groceryItemRepository.existsById(id)) {
            groceryItem.setId(id);
            return groceryItemRepository.save(groceryItem);
        }
        return null; // No exception; handle at the controller level
    }

    @Override
    public void deleteGroceryItem(Long id) {
        groceryItemRepository.deleteById(id);
    }

    @Override
    public List<GroceryItem> getAllGroceryItems() {
        return groceryItemRepository.findAll();
    }

    @Override
    public GroceryItem getGroceryItemById(Long id) {
        return groceryItemRepository.findById(id).orElse(null);
    }

    @Override
    public List<GroceryItem> searchByName(String name) {
        return groceryItemRepository.findByNameContainingIgnoreCase(name);
    }

    @Override
    public List<GroceryItem> searchByCategory(String category) {
        return groceryItemRepository.findByCategoryContainingIgnoreCase(category);
    }
}
