package com.example.grocerystore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroceryItemApplication {
    public static void main(String[] args) {
        SpringApplication.run(GroceryItemApplication.class, args);
    }
}
