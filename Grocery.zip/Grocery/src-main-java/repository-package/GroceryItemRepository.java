package com.example.grocerystore.repository;

import com.example.grocerystore.model.GroceryItem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface GroceryItemRepository extends JpaRepository<GroceryItem, Long> {
    List<GroceryItem> findByNameContainingIgnoreCase(String name); // Search by name
    List<GroceryItem> findByCategoryContainingIgnoreCase(String category); // Search by category
}
