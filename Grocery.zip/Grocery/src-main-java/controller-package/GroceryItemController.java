package com.example.grocerystore.controller;

import com.example.grocerystore.model.GroceryItem;
import com.example.grocerystore.service.GroceryItemService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/grocery-items")
public class GroceryItemController {

    private final GroceryItemService groceryItemService;

    public GroceryItemController(GroceryItemService groceryItemService) {
        this.groceryItemService = groceryItemService;
    }

    // Retrieve all grocery items
    @GetMapping
    public List<GroceryItem> getAllGroceryItems() {
        return groceryItemService.getAllGroceryItems();
    }

    // Retrieve a specific grocery item by ID
    @GetMapping("/{id}")
    public ResponseEntity<GroceryItem> getGroceryItemById(@PathVariable Long id) {
        GroceryItem groceryItem = groceryItemService.getGroceryItemById(id);
        if (groceryItem != null) {
            return new ResponseEntity<>(groceryItem, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Add a new grocery item
    @PostMapping
    public ResponseEntity<GroceryItem> addGroceryItem(@RequestBody GroceryItem groceryItem) {
        GroceryItem addedItem = groceryItemService.addGroceryItem(groceryItem);
        return new ResponseEntity<>(addedItem, HttpStatus.CREATED);
    }

    // Update an existing grocery item
    @PutMapping("/{id}")
    public ResponseEntity<GroceryItem> updateGroceryItem(@PathVariable Long id, @RequestBody GroceryItem groceryItem) {
        GroceryItem updatedItem = groceryItemService.updateGroceryItem(id, groceryItem);
        if (updatedItem != null) {
            return new ResponseEntity<>(updatedItem, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete a grocery item
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGroceryItem(@PathVariable Long id) {
        groceryItemService.deleteGroceryItem(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    // Search grocery items by name
    @GetMapping("/search")
    public List<GroceryItem> searchGroceryItems(@RequestParam(required = false) String name,
                                                @RequestParam(required = false) String category) {
        if (name != null) {
            return groceryItemService.searchByName(name);
        } else if (category != null) {
            return groceryItemService.searchByCategory(category);
        } else {
            return groceryItemService.getAllGroceryItems();
        }
    }
	
	@GetMapping("/grocery-items")
	public String listGroceryItems(Model model) {
    model.addAttribute("groceryItems", groceryItemService.getAllGroceryItems());
    return "index";
	}

	@GetMapping("/grocery-items/new")
	public String showCreateForm(Model model) {
    model.addAttribute("item", new GroceryItem());
    return "form";
	}

	@GetMapping("/grocery-items/{id}/edit")
	public String showEditForm(@PathVariable Long id, Model model) {
    GroceryItem item = groceryItemService.getGroceryItemById(id);
    model.addAttribute("item", item);
    return "form";
	}

}
